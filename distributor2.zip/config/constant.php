<?php

return [
    'unit' => ['KG', 'Meter', 'Inch', 'Ton', 'Liter', 'Piece'],
    'company' => ['name' => 'AH Distributors', 'address' => 'Ambag, Konabari, Gazipur', 'phone' => '01701235445, 01456238456']
];
